package br.edu.fatecpg.perfilusuario.dao

import androidx.room.*
import br.edu.fatecpg.perfilusuario.model.Usuario

@Dao
interface UsuarioDao {

    @Insert
    suspend fun inserir(usuario: Usuario)

    @Query(
        "SELECT * FROM Usuario WHERE email = :email AND senha = :senha"
    )
    suspend fun login(
        email: String,
        senha: String
    ): Usuario?

    @Query("SELECT * FROM Usuario")
    suspend fun listar(): List<Usuario>

    @Update
    suspend fun atualizar(usuario: Usuario)

    @Delete
    suspend fun deletar(usuario: Usuario)
}