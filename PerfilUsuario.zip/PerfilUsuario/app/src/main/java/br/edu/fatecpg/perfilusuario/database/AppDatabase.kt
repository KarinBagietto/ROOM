package br.edu.fatecpg.perfilusuario.database

import androidx.room.Database
import androidx.room.RoomDatabase
import br.edu.fatecpg.perfilusuario.dao.UsuarioDao
import br.edu.fatecpg.perfilusuario.model.Usuario

@Database(
    entities = [Usuario::class],
    version = 1
)

abstract class AppDatabase : RoomDatabase() {

    abstract fun usuarioDao(): UsuarioDao
}