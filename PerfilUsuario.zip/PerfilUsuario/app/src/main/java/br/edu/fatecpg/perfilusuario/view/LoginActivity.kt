package br.edu.fatecpg.perfilusuario.view

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.room.Room
import br.edu.fatecpg.perfilusuario.database.AppDatabase
import br.edu.fatecpg.perfilusuario.databinding.ActivityLoginBinding
import kotlinx.coroutines.launch

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding

    private lateinit var db: AppDatabase

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)

        binding = ActivityLoginBinding.inflate(layoutInflater)

        setContentView(binding.root)

        db = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java,
            "usuarios-db"
        ).build()

        binding.btnCadastro.setOnClickListener {

            startActivity(
                Intent(this, CadastroActivity::class.java)
            )
        }

        binding.btnLogin.setOnClickListener {

            val email = binding.editEmail.text.toString()

            val senha = binding.editSenha.text.toString()

            lifecycleScope.launch {

                val usuario = db.usuarioDao()
                    .login(email, senha)

                if(usuario != null){

                    val intent = Intent(
                        this@LoginActivity,
                        PerfilActivity::class.java
                    )

                    intent.putExtra("id", usuario.id)

                    intent.putExtra("nome", usuario.nome)

                    intent.putExtra("email", usuario.email)

                    intent.putExtra("whatsapp", usuario.whatsapp)

                    intent.putExtra("endereco", usuario.endereco)

                    startActivity(intent)

                }else{

                    Toast.makeText(
                        this@LoginActivity,
                        "Email ou senha inválidos",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }
    }
}