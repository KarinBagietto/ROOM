package br.edu.fatecpg.perfilusuario.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class Usuario(

    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,

    val nome: String,

    val email: String,

    val senha: String,

    val whatsapp: String,

    val endereco: String
)

