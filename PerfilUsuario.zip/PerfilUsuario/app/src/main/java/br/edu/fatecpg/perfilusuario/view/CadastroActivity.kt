package br.edu.fatecpg.perfilusuario.view

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.room.Room
import br.edu.fatecpg.perfilusuario.database.AppDatabase
import br.edu.fatecpg.perfilusuario.databinding.ActivityCadastroBinding
import br.edu.fatecpg.perfilusuario.model.Usuario
import kotlinx.coroutines.launch

class CadastroActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCadastroBinding

    private lateinit var db: AppDatabase

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)

        binding = ActivityCadastroBinding.inflate(layoutInflater)

        setContentView(binding.root)

        db = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java,
            "usuarios-db"
        ).build()

        binding.btnSalvar.setOnClickListener {

            val usuario = Usuario(

                nome = binding.editNome.text.toString(),

                email = binding.editEmail.text.toString(),

                senha = binding.editSenha.text.toString(),

                whatsapp = binding.editWhatsapp.text.toString(),

                endereco = binding.editEndereco.text.toString()
            )

            lifecycleScope.launch {

                db.usuarioDao().inserir(usuario)

                Toast.makeText(
                    this@CadastroActivity,
                    "Usuário salvo",
                    Toast.LENGTH_SHORT
                ).show()

                finish()
            }
        }
    }
}