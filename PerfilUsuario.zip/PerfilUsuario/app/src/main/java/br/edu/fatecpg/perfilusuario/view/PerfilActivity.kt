package br.edu.fatecpg.perfilusuario.view

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.room.Room
import br.edu.fatecpg.perfilusuario.database.AppDatabase
import br.edu.fatecpg.perfilusuario.databinding.ActivityPerfilBinding
import br.edu.fatecpg.perfilusuario.model.Usuario
import kotlinx.coroutines.launch

class PerfilActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPerfilBinding

    private lateinit var db: AppDatabase

    private var usuarioId = 0

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)

        binding = ActivityPerfilBinding.inflate(layoutInflater)

        setContentView(binding.root)

        db = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java,
            "usuarios-db"
        ).build()

        usuarioId = intent.getIntExtra("id", 0)

        binding.editNome.setText(
            intent.getStringExtra("nome")
        )

        binding.editEmail.setText(
            intent.getStringExtra("email")
        )

        binding.editWhatsapp.setText(
            intent.getStringExtra("whatsapp")
        )

        binding.editEndereco.setText(
            intent.getStringExtra("endereco")
        )

        binding.btnAtualizar.setOnClickListener {

            val usuario = Usuario(

                id = usuarioId,

                nome = binding.editNome.text.toString(),

                email = binding.editEmail.text.toString(),

                senha = "",

                whatsapp = binding.editWhatsapp.text.toString(),

                endereco = binding.editEndereco.text.toString()
            )

            lifecycleScope.launch {

                db.usuarioDao().atualizar(usuario)

                Toast.makeText(
                    this@PerfilActivity,
                    "Atualizado",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        binding.btnExcluir.setOnClickListener {

            val usuario = Usuario(
                id = usuarioId,
                nome = "",
                email = "",
                senha = "",
                whatsapp = "",
                endereco = ""
            )

            lifecycleScope.launch {

                db.usuarioDao().deletar(usuario)

                Toast.makeText(
                    this@PerfilActivity,
                    "Conta excluída",
                    Toast.LENGTH_SHORT
                ).show()

                finish()
            }
        }
    }
}